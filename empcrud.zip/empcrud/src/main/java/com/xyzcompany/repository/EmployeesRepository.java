package com.xyzcompany.repository;
import org.springframework.data.repository.CrudRepository;

import com.xyzcompany.model.Employees;
public interface EmployeesRepository extends CrudRepository<Employees, Integer>
{
}
